

---------- Forwarded message ----------
From: McClements, Ken G <k.g.mcclements@ccfe.ac.uk>
Date: Tue, Mar 1, 2011 at 10:37 PM
Subject: RE: intro
To: Colm Morrison <colm.morrison@gmail.com>
Cc: "Hole, Matthew J" <matthew.hole@ccfe.ac.uk>


Colm,
 
As promised, I attach a version of CUEBIT that you should be able to compile and run at ANU. This is for a single, collisionless charged particle in an analytically-prescribed equilibrium magnetic field which approximates the field in the MAST experiment at Culham. I have used this equilibrium in a number of papers - see e.g. Plasma Physics and Controlled Fusion 49 (2007) 1415. 
 
This version of the code doesn't use any libraries; if you have the standard Intel fortran compiler it should compile successfully when you type
 
ifort CUEBIT_MAST_ripple.f -o CUEBIT_MAST_ripple
 
An example of the input data for this version of CUEBIT is in the file inputdata.dat. This has two lines of input data, as follows:

1.2 (initial particle major radius in m) 0.0 (initial particle height above or below midplane in m) 0.0 (initial toroidal angle in degrees) 0.0 (initial vx) 1.2d5 (initial vy) 2.3d5 (initial vz)

(Here vx, vy, vz are cartesian velocity components, referred to a set of axes that are related to the cylindrical coordinates (R,phi,Z) defining the initial particle position in the standard way. The values given above are for a typical ion in MAST, with an energy of the order of 1 keV).

The 2nd line of input data is as follows:

2.0 (particle mass number) 1.0 (particle charge state) 0.1 (timestep in units of cyclotron period at magnetic axis) 10000 (number of time steps) 1.0 (fraction of time steps output)

Both thermal ions and beam ions in MAST are deuterium - hence the choice of mass number and charge state.

If compilation is successful, you can run the code simply by typing

CUEBIT_MAST_ripple

This generates two ouput files containing the orbit: orbit.dat contains the output required for a very simple IDL plotting code (orbit.pro), and full_orbit.dat contains also headings, indicating what the variables are. The last column in full_orbit.dat gives the relative error in the toroidal canonical momentum. This is an exact invariant of the equation of motion but not of the finite difference equation being used to approximate it; hence the error in this quantity is a measure of how accurately the code is computing the orbit - if it it not very small (absolute value much smaller than 1), this usually means that you have to reduce the timestep.   

Assuming that you have IDL, you can plot the orbit by typing

IDL> .r orbit.pro

IDL> orbit

IDL> exit

This generates a .ps file showing the particle orbit in the (R,Z) plan (orbit.ps).

If you are able to do all of the above, you can then try changing the physical and numerical parameters in inputdata.dat. For example you could determine the effect of changing the timestep on the relative error in toroidal momentum. By varying the direction of the initial velocity, you can generate either trapped or passing orbits, and by increasing the absolute values of the velocity components you can see what happens in the case of energetic beam ions. Alternatively, by setting Z = -1 and A = 1/1836 you can simulate electron orbits.    

Good luck! Let me know how you get on with this, and feel free to bombarb me with questions.
Ken

Dr K G McClements
EURATOM/CCFE Fusion Association
Culham Science Centre
Abingdon
Oxfordshire
OX14 3DB
United Kingdom
Tel: +44 (0)1235 466303
http://www.ccfe.ac.uk/researcher_detail.aspx?id=990885

    -----Original Message-----
    From: Colm Morrison [mailto:colm.morrison@gmail.com]
    Sent: 01 March 2011 05:38
    To: McClements, Ken G
    Subject: Re: intro

    Hi Ken,

    Matthew has given me some of your papers and numerous other texts to read. We were wondering if it's possible to get the CUEBIT code so that I can play around with it before you arrived. It only runs on Linux right?

    Regards,
    Colm Morrison

    On Mon, Feb 28, 2011 at 6:20 PM, McClements, Ken G <k.g.mcclements@ccfe.ac.uk> wrote:

        Dear Colm,

        Matthew told me that you were happy for me to have your e-mail address;
        I'm contacting you now to introduce myself. I understand that Matthew
        has set you some background reading - feel free to contact me at any
        time if you have any questions about this material, or any specific
        questions about your project and/or the CUEBIT code.

        I look forward to meeting you in a few weeks; I expect to be at ANU from
        Monday March 28 onwards.

        Best wishes

        Ken

        Dr K G McClements
        EURATOM/CCFE Fusion Association
        Culham Science Centre
        Abingdon
        Oxfordshire
        OX14 3DB
        United Kingdom
        Tel: +44 (0)1235 466303
        http://www.ccfe.ac.uk/researcher_detail.aspx?id=990885


