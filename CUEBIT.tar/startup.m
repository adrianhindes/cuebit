addpath /home/hol105/MHD_codes/CUEBIT/MAST
